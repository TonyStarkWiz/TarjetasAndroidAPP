package Anthony.proyecto.tarjetas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import Anthony.proyecto.tarjetas.ui.theme.TarjetasTheme
import android.media.Image
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TarjetasTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun MyApp() {
    val imagesList = listOf(R.drawable.cool_guy_2, R.drawable.girl, R.drawable.cool_guy_colors)
    LazyRow (modifier = Modifier.fillMaxWidth()){
        item {
            for (img in imagesList) {
                Greeting(name = "Anthony", image = img)
            }
        }
    }
}

@Composable
fun Greeting(name: String, image: Int = R.drawable.cool_guy_colors) {
    Column (modifier = Modifier.width(320.dp)) {
        Image(
            painter = painterResource(id = image),
            contentDescription = "Nino cool con fondo de colores", modifier =
            Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            contentScale = ContentScale.FillWidth
        )
        Text(
            text = "Hello $name!", modifier = Modifier.fillMaxWidth(), fontSize = 26.sp, textAlign
            = TextAlign.Center
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Image(painter = painterResource(id = R.drawable.like), contentDescription = "like")
            Text(text = "Like")
            Image(painter = painterResource(id = R.drawable.share), contentDescription = "Share")
            Text(text = "Share")
            Image(painter = painterResource(id = R.drawable.save), contentDescription = "Save")
            Text(text = "Save")
        }
    }
}

@Preview(showBackground = true, widthDp = 320)
@Composable
fun GreetingPreview() {
    TarjetasTheme {
        MyApp()
    }
}
